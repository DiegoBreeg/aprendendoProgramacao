

function pedido (item, valor, validade, peso, preparo){ 
    return {           
        item,
        valor,
        validade,
        peso,
        preparo,
    }
}

    






export {pedido};